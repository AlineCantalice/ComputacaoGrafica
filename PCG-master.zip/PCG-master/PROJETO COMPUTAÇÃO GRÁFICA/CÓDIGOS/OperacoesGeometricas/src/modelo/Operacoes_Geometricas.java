package modelo;

import java.awt.image.BufferedImage;
import processarImagem.PanelDaImagem;
import view.Tela_Resultado;

public class Operacoes_Geometricas extends PanelDaImagem {

    boolean flag = true;
    int contador = 0;
    int contador2 = 0;
    int contador3 = 0;
    Tela_Resultado t;

    public void cisalhamento(int largura, int altura, int[][] matrizImagem, double valor_x, double valor_y) {

        BufferedImage imagem_auxiliar = new BufferedImage(altura, largura, BufferedImage.TYPE_INT_RGB);
        int matriz_auxiliar[][] = new int[altura + 100][largura + 100];

        for (int y = 0; y < imagem_auxiliar.getHeight(); y++) {
            for (int x = 0; x < imagem_auxiliar.getWidth(); x++) {

                int cisalha_x = (int) (y + (x * (valor_x)) - ((altura * (valor_x)) / 2));
                int cisalha_y = (int) (x + (y * (valor_y)) - ((largura * (valor_y)) / 2));

                if (cisalha_x < 0) {
                    cisalha_x = 0;
                }
                if (cisalha_y < 0) {
                    cisalha_y = 0;
                }

                matriz_auxiliar[cisalha_x][cisalha_y] = matrizImagem[x][y];
            }
        }
        exibir(matriz_auxiliar);
    }

    public void escala_mais(int largura, int altura, int[][] matrizImagem, double fator) {
        int fat = (int) Math.round(fator);
        BufferedImage imagem_auxiliar = new BufferedImage(altura, largura, BufferedImage.TYPE_INT_RGB);
        BufferedImage escala_mais = new BufferedImage(altura * fat, largura * fat, BufferedImage.TYPE_INT_RGB);
        int matriz_auxiliar[][] = new int[altura * fat][largura * fat];

        double mais = fator;

        for (int y = 0; y < imagem_auxiliar.getHeight(); y++) {
            for (int x = 0; x < imagem_auxiliar.getWidth(); x++) {

                int f = (int) (x * mais);// x + (y*1);
                int g = (int) (y * mais);// x+ (y*0);

                matriz_auxiliar[f][g] = matrizImagem[x][y];

                if (f < 0) {
                    f = 0;
                }
                if (g < 0) {
                    g = 0;
                }

                escala_mais.setRGB(g, f, corPixel(matriz_auxiliar[f][g]));
            }
        }
        // Se a imagem for maior, abre em uma nova tela
        if (escala_mais.getWidth() > 260) {
            t = new Tela_Resultado(escala_mais, "Escala");
        }
        exibir(matriz_auxiliar);
    }

    public int[][] escala_menos(int altura, int largura, int[][] matrizImagem, double fator) {
        BufferedImage imagem_auxiliar = new BufferedImage(altura, largura, BufferedImage.TYPE_INT_RGB);

        int matriz_auxiliar[][] = new int[altura][largura];

        double menos = fator;

        for (int y = 0; y < imagem_auxiliar.getHeight(); y++) {
            for (int x = 0; x < imagem_auxiliar.getWidth(); x++) {

                int f = (int) (x * menos);// x + (y*1);
                int g = (int) (y * menos);// x+ (y*0);

                matriz_auxiliar[f][g] = matrizImagem[x][y];
            }
        }
        this.matrizImagem = matriz_auxiliar;
        exibir(matriz_auxiliar);
        return matriz_auxiliar;
    }

    public void reflexao(int altura, int largura, int[][] matrizImagem, int valor_x, int valor_y) {
        BufferedImage imagem_auxiliar = new BufferedImage(altura, largura, BufferedImage.TYPE_INT_RGB);
        int matriz_auxiliar[][] = new int[altura][largura];

        for (int x = 0; x < altura; x++) {
            for (int y = 0; y < largura; y++) {

                if (valor_x == -1 && valor_y == -1) {
                    matriz_auxiliar[Math.abs(255 - y)][Math.abs(255 - x)] = matrizImagem[y][x];//Invertida para XY OK

                }
                if (valor_x == 0 && valor_y == -1) {
                    matriz_auxiliar[Math.abs(y)][Math.abs(255 - x)] = matrizImagem[y][x];//Invertida para Y OK

                }
                if (valor_x == -1 && valor_y == 0) {
                    matriz_auxiliar[Math.abs(255 - y)][Math.abs(x)] = matrizImagem[y][x];//Invertida para X OK
                }
                if (valor_x == 0 && valor_y == 0) {
                    matriz_auxiliar[x][y] = matrizImagem[x][y];
                }
            }
        }
        exibir(matriz_auxiliar);
    }

    public void translacao(int altura, int largura, int[][] matrizImagem, int valor_x, int valor_y) {
        /*BufferedImage imagem_auxiliar = new BufferedImage(altura, largura, BufferedImage.TYPE_INT_RGB);
		int matriz_auxiliar[][] = new int[altura + altura][largura + largura];*/
        BufferedImage imagem_auxiliar = new BufferedImage(altura, largura, BufferedImage.TYPE_INT_RGB);
        int matriz_auxiliar[][] = new int[altura * 2][largura * 2];

        for (int y = 0; y < imagem_auxiliar.getHeight(); y++) {
            for (int x = 0; x < imagem_auxiliar.getWidth(); x++) {

                matriz_auxiliar[Math.abs(valor_x + x)][Math.abs(valor_y + y)] = matrizImagem[x][y];//Invertida para X OK

            }
        }
        exibir(matriz_auxiliar);
    }

    public void rotacao(int largura, int altura, int[][] matrizImagem, int angulo) {
        int matriz_auxiliar[][] = new int[altura][largura];

        switch (angulo) {
            case 90:
                matriz_auxiliar = rotacionarMatrizHorario(matrizImagem);
                break;
            case -90:
                matriz_auxiliar = rotacionarMatrizAntiHorario(matrizImagem);
                break;
            case -180:
                matriz_auxiliar = rotacionarMatrizHorario(matrizImagem);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                break;
            case 180:
                matriz_auxiliar = rotacionarMatrizHorario(matrizImagem);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                break;
            case 270:
                matriz_auxiliar = rotacionarMatrizHorario(matrizImagem);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                break;
            case -270:
                matriz_auxiliar = rotacionarMatrizHorario(matrizImagem);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                break;
            case -360:
                matriz_auxiliar = rotacionarMatrizHorario(matrizImagem);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                break;
            case 360:
                matriz_auxiliar = rotacionarMatrizHorario(matrizImagem);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                matriz_auxiliar = rotacionarMatrizHorario(matriz_auxiliar);
                break;
            default:
                break;
        }

        exibir(matriz_auxiliar);
    }

    public static int[][] rotacionarMatrizHorario(int[][] matriz) {
        int largura = matriz.length;
        int altura = matriz[0].length;
        int[][] ret = new int[altura][largura];
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < largura; j++) {
                ret[i][j] = matriz[largura - j - 1][i];
            }
        }
        return ret;
    }

    public static int[][] rotacionarMatrizAntiHorario(int[][] matriz) {
        int largura = matriz.length;
        int altura = matriz[0].length;
        int[][] ret = new int[altura][largura];
        for (int i = 0; i < altura; i++) {
            for (int j = 0; j < largura; j++) {
                ret[i][j] = matriz[j][altura - i - 1];
            }
        }
        return ret;
    }
}
